package warehouse.service;

import warehouse.dao.ProductDAO;
import warehouse.model.Product;
import warehouse.util.QRCodeUtil;

public class ProductService {

    private ProductDAO dao = new ProductDAO();

    public Product registerProduct(String name, String category,
                                   int qty, String location, double price) {

        String qr = QRCodeUtil.generateQRCode(category);

        Product p = new Product(qr, name, category, qty, location, price);

        dao.addProduct(p);

        return p;
    }

    public Product findProduct(String qr) {
        return dao.getByQRCode(qr);
    }
}