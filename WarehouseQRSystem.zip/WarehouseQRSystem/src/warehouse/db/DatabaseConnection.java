package warehouse.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {

    private static final String URL = "jdbc:sqlite:warehouse.db";

    public static Connection getConnection() {
        try {
            
            Class.forName("org.sqlite.JDBC");

            Connection conn = DriverManager.getConnection(URL);
            System.out.println("[DB] Connected successfully.");
            return conn;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}