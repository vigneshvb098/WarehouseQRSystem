package warehouse.db;

	import java.sql.Connection;
	import java.sql.Statement;

	public class SchemaInitializer {

	    public static void initialize() {
	        try {
	            Connection conn = DatabaseConnection.getConnection();
	            Statement stmt = conn.createStatement();

	            String sql = "CREATE TABLE IF NOT EXISTS products (" +
	                    "product_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
	                    "qr_code TEXT UNIQUE, " +
	                    "product_name TEXT, " +
	                    "category TEXT, " +
	                    "quantity INTEGER, " +
	                    "location TEXT, " +
	                    "unit_price REAL, " +
	                    "entry_date TEXT, " +
	                    "last_updated TEXT, " +
	                    "status TEXT" +
	                    ");";

	            stmt.execute(sql);

	            System.out.println("[DB] Tables created.");

	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	    }
	}

