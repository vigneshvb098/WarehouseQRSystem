package warehouse.model;

import java.time.LocalDateTime;

public class Product {

    private int productId;
    private String qrCode;
    private String productName;
    private String category;
    private int quantity;
    private String location;
    private double unitPrice;
    private LocalDateTime entryDate;
    private LocalDateTime lastUpdated;
    private String status;

    public Product(String qrCode, String name, String category,
                   int qty, String location, double price) {

        this.qrCode = qrCode;
        this.productName = name;
        this.category = category;
        this.quantity = qty;
        this.location = location;
        this.unitPrice = price;
        this.entryDate = LocalDateTime.now();
        this.lastUpdated = LocalDateTime.now();
        this.status = "ACTIVE";
    }

    // Getters
    public String getQrCode() { return qrCode; }
    public String getProductName() { return productName; }
    public String getCategory() { return category; }
    public int getQuantity() { return quantity; }
    public String getLocation() { return location; }
    public double getUnitPrice() { return unitPrice; }
    public String getStatus() { return status; }
    public int getProductId() { return productId; }

    public void setProductId(int id) { this.productId = id; }
}