package warehouse.dao;

import warehouse.db.DatabaseConnection;
import warehouse.model.Product;

import java.sql.*;

public class ProductDAO {

    public boolean addProduct(Product p) {
        String sql = "INSERT INTO products(qr_code, product_name, category, quantity, location, unit_price, entry_date, last_updated, status) VALUES(?,?,?,?,?,?,?,?,?)";

        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, p.getQrCode());
            ps.setString(2, p.getProductName());
            ps.setString(3, p.getCategory());
            ps.setInt(4, p.getQuantity());
            ps.setString(5, p.getLocation());
            ps.setDouble(6, p.getUnitPrice());
            ps.setString(7, p.getStatus());
            ps.setString(8, p.getStatus());
            ps.setString(9, p.getStatus());

            int rows = ps.executeUpdate();

            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                p.setProductId(rs.getInt(1));
            }

            return rows > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public Product getByQRCode(String qr) {
        try {
            Connection conn = DatabaseConnection.getConnection();
            PreparedStatement ps = conn.prepareStatement(
                    "SELECT * FROM products WHERE qr_code=?");

            ps.setString(1, qr);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Product(
                        rs.getString("qr_code"),
                        rs.getString("product_name"),
                        rs.getString("category"),
                        rs.getInt("quantity"),
                        rs.getString("location"),
                        rs.getDouble("unit_price")
                );
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}