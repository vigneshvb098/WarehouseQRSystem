package warehouse.ui;

import warehouse.db.SchemaInitializer;
import warehouse.model.Product;
import warehouse.service.ProductService;

import java.util.Scanner;

public class WarehouseApp {

    
    public static void main(String[] args) {

        SchemaInitializer.initialize();

        @SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
        ProductService service = new ProductService();

        while (true) {

            System.out.println("\n1. Add Product");
            System.out.println("2. Search by QR");
            System.out.println("0. Exit");

            int choice = sc.nextInt();

            if (choice == 1) {

                sc.nextLine();
                System.out.print("Name: ");
                String name = sc.nextLine();

                System.out.print("Category: ");
                String cat = sc.nextLine();

                System.out.print("Qty: ");
                int qty = sc.nextInt();

                sc.nextLine();
                System.out.print("Location: ");
                String loc = sc.nextLine();

                System.out.print("Price: ");
                double price = sc.nextDouble();

                Product p = service.registerProduct(name, cat, qty, loc, price);

                System.out.println("Product Added!");
                System.out.println("QR Code: " + p.getQrCode());
            }

            else if (choice == 2) {
                sc.nextLine();
                System.out.print("Enter QR: ");
                String qr = sc.nextLine();

                Product p = service.findProduct(qr);

                if (p != null) {
                    System.out.println("Name: " + p.getProductName());
                    System.out.println("Stock: " + p.getQuantity());
                } else {
                    System.out.println("Not found!");
                }
            }

            else if (choice == 0) {
                break;
            }
        }
    }
}