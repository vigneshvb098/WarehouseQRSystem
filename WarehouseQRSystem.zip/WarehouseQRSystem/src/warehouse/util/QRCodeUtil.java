package warehouse.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

public class QRCodeUtil {

    public static String generateQRCode(String category) {

        String cat = category.substring(0, 3).toUpperCase();
        String time = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"));

        String rand = UUID.randomUUID().toString()
                .replace("-", "").substring(0, 6).toUpperCase();

        return "WH-" + cat + "-" + time + "-" + rand;
    }
}